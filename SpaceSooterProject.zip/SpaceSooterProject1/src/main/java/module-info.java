module com.example.spacesooterproject1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.sql;
    requires java.prefs;


    opens com.example.spacesooterproject1 to javafx.fxml;
    exports com.example.spacesooterproject1;
}